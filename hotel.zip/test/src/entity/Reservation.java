/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;
import static com.sun.org.apache.xalan.internal.lib.ExsltDatetime.dateTime;
/**
 *
 * @author Eric
 */
public class Reservation 
{
    private int reservationID;
    private int guestID;
    private int employeeID;
    private int roomID;
    private String checkIn;
    
    public Reservation(int reservationID, int guestID,  int employeeID, int roomID, String checkIn)
    {
        this.reservationID = reservationID;
        this.guestID = guestID;
        this.employeeID = employeeID;
        this.roomID = roomID;
        this.checkIn = checkIn;

    }
    public int getReservationID() {
        return reservationID;
    }
    
    public int getGuestID() {
        return guestID;
    }
    
    public int getEmployeeID() {
        return employeeID;
    }
    
    public int getRoomID() {
        return roomID;
    }

    public String getCheckIn() {
        return checkIn;
    }

    @Override
    public String toString() {
        return "Reservation{" + "reservationID=" + reservationID + "guestID=" + guestID + "employeeID=" + employeeID + "roomID=" + roomID + "checkIn=" + checkIn + '}';
    }
}
