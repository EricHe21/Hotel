/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;
/**
 *
 * @author Gokhan
 */
public class Guest 
{
    private int guestID;
    private String guestFirstName;
    private String guestLastName;
    
    public Guest(int guestID, String guestFirstName, String guestLastName)
    {
        this.guestID = guestID;
        this.guestFirstName = guestFirstName;
        this.guestLastName = guestLastName;

    }

    public int getGuestID() {
        return guestID;
    }

    public String getGuestFirstName() {
        return guestFirstName;
    }

    public String getGuestLastName() {
        return guestLastName;
    }

    @Override
    public String toString() {
        return "Guest{" + "guestID=" + guestID + ", guestFirstName=" + guestFirstName + ", guestLastName=" + guestLastName + '}';
    }
}
