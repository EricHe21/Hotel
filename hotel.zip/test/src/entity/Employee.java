/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;
/**
 *
 * @author Gokhan
 */
public class Employee 
{
    private int employeeID;
    private String employeeFirstName;
    private String employeeLastName;
    
    public Employee(int employeeID, String employeeFirstName, String employeeLastName)
    {
        this.employeeID = employeeID;
        this.employeeFirstName = employeeFirstName;
        this.employeeLastName = employeeLastName;

    }

    public int getEmployeeID() {
        return employeeID;
    }


    public String getEmployeeFirstName() {
        return employeeFirstName;
    }

    public String getEmployeeLastName() {
        return employeeLastName;
    }
    

    @Override
    public String toString() {
        return "Employee{" + "employeeID=" + employeeFirstName + ", employeeFirstName=" + employeeFirstName + ", employeeLastName=" + employeeLastName + '}';
    }
}
