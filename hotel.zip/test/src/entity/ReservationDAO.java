/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import core.*;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
/**
 *
 * @author Gokhan
 */
public class ReservationDAO implements DAO<Reservation>
{   
    public ReservationDAO() {
        
    }
    List<Reservation> reservations;
    /**
     * Get a single customer entity as a customer object
     * @param id
     * @return 
     */
    @Override
    public Optional<Reservation> get(int id) {
        DB db = DB.getInstance();
        ResultSet rs = null;
        try {
            String sql = "SELECT * FROM HT_Reservation WHERE reservationID = ?";
            PreparedStatement stmt = db.getPreparedStatement(sql);
            stmt.setInt(1, id);
            rs = stmt.executeQuery();
            Reservation reservation = null;
            while (rs.next()) {
                reservation = new Reservation(rs.getInt("reservationID"), rs.getInt("guestID"), rs.getInt("employeeID"), rs.getInt("roomID"), rs.getString("checkIn"));
            }
            return Optional.ofNullable(reservation);
        } catch (SQLException ex) {
            System.err.println(ex.toString());
            return null;
        }
    }
    
    /**
     * Get all customer entities as a List
     * @return 
     */
    @Override
    public List<Reservation> getAll() {
        DB db = DB.getInstance();
        ResultSet rs = null;
        reservations = new ArrayList<>();
        try {
            String sql = "SELECT * FROM HT_Reservation";
            rs = db.executeQuery(sql);
            Reservation reservation = null;
            while (rs.next()) {
                reservation = new Reservation(rs.getInt("reservationID"), rs.getInt("guestID"), rs.getInt("employeeID"), rs.getInt("roomID"), rs.getString("checkIn"));
                reservations.add(reservation);
            }
            return reservations;
        } catch (SQLException ex) {
            System.err.println(ex.toString());
            return null;
        }
    }
    
    /**
     * Insert a customer object into customer table
     * @param reservation 
     */
    @Override
    public void insert(Reservation reservation)
    {
        DB db = DB.getInstance();
        try {
            String sql = "INSERT INTO HT_Reservation(reservationID, guestID, employeeID, roomID, checkIn) VALUES (?, ?, ?, ?,?)";
            PreparedStatement stmt = db.getPreparedStatement(sql);
            stmt.setInt(1, reservation.getReservationID());
            stmt.setInt(2, reservation.getGuestID());
            stmt.setInt(3, reservation.getEmployeeID());
            stmt.setInt(4, reservation.getRoomID());
            stmt.setString(5, reservation.getCheckIn());
            int rowInserted = stmt.executeUpdate();
            if (rowInserted > 0) {
                System.out.println("A new reservation was inserted successfully!");
            }
        } catch (SQLException ex) {
            System.err.println(ex.toString());
        }
    }
    
    /**
     * Update a customer entity in database if it exists using a customer object
     * @param reservation
     */
    @Override
    public void update(Reservation reservation) {
        DB db = DB.getInstance();
        try {
            String sql = "UPDATE HT_Reservation SET guestID=?, employeeID=?, roomID=?, checkIn=? WHERE reservationID=?";
            PreparedStatement stmt = db.getPreparedStatement(sql);
            stmt.setInt(1, reservation.getGuestID());
            stmt.setInt(2, reservation.getEmployeeID());
            stmt.setInt(3, reservation.getRoomID());      
            stmt.setString(4, reservation.getCheckIn());
            stmt.setInt(5, reservation.getReservationID());
            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("An existing reservation was updated successfully!");
            }
        } catch (SQLException ex) {
            System.err.println(ex.toString());
        }
    }
    
    /**
     * Delete a customer from customer table if the entity exists
     * @param reservation 
     */
    @Override
    public void delete(Reservation reservation) {
        DB db = DB.getInstance();
        try {
            String sql = "DELETE FROM HT_Reservation WHERE reservationID = ?";
            PreparedStatement stmt = db.getPreparedStatement(sql);
            stmt.setInt(1, reservation.getReservationID());
            int rowsDeleted = stmt.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("A reservation was deleted successfully!");
            }
        } catch (SQLException ex) {
            System.err.println(ex.toString());
        }
    }
    
    /**
     * Get all column names in a list array
     * @return 
     */
    @Override
    public List<String> getColumnNames() {
        DB db = DB.getInstance();
        ResultSet rs = null;
        List<String> headers = new ArrayList<>();
        try {
            String sql = "SELECT * FROM HT_Reservation WHERE reservationID = -1";//We just need this sql query to get the column headers
            rs = db.executeQuery(sql);
            ResultSetMetaData rsmd = rs.getMetaData();
            //Get number of columns in the result set
            int numberCols = rsmd.getColumnCount();
            for (int i = 1; i <= numberCols; i++) {
                headers.add(rsmd.getColumnLabel(i));//Add column headers to the list
            }
            return headers;
        } catch (SQLException ex) {
            System.err.println(ex.toString());
            return null;
        } 
    }
}
