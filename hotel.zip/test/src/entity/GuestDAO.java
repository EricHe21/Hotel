/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import core.*;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
/**
 *
 * @author Gokhan
 */
public class GuestDAO implements DAO<Guest>
{   
    public GuestDAO() {
        
    }
    List<Guest> guests;
    /**
     * Get a single customer entity as a customer object
     * @param id
     * @return 
     */
    @Override
    public Optional<Guest> get(int id) {
        DB db = DB.getInstance();
        ResultSet rs = null;
        try {
            String sql = "SELECT * FROM HT_Guest WHERE guestID = ?";
            PreparedStatement stmt = db.getPreparedStatement(sql);
            stmt.setInt(1, id);
            rs = stmt.executeQuery();
            Guest guest = null;
            while (rs.next()) {
                guest = new Guest(rs.getInt("guestID"), rs.getString("guestFirstName"), rs.getString("guestLastName"));
            }
            return Optional.ofNullable(guest);
        } catch (SQLException ex) {
            System.err.println(ex.toString());
            return null;
        }
    }
    
    /**
     * Get all customer entities as a List
     * @return 
     */
    @Override
    public List<Guest> getAll() {
        DB db = DB.getInstance();
        ResultSet rs = null;
        guests = new ArrayList<>();
        try {
            String sql = "SELECT * FROM HT_Guest";
            rs = db.executeQuery(sql);
            Guest guest = null;
            while (rs.next()) {
                guest = new Guest(rs.getInt("guestID"), rs.getString("guestFirstName"), rs.getString("guestLastName"));
                guests.add(guest);
            }
            return guests;
        } catch (SQLException ex) {
            System.err.println(ex.toString());
            return null;
        }
    }
    
    /**
     * Insert a customer object into customer table
     * @param guest 
     */
    @Override
    public void insert(Guest guest)
    {
        DB db = DB.getInstance();
        try {
            String sql = "INSERT INTO HT_Guest(guestID, guestFirstName, guestLastName) VALUES (?, ?, ?)";
            PreparedStatement stmt = db.getPreparedStatement(sql);
            stmt.setInt(1, guest.getGuestID());
            stmt.setString(2, guest.getGuestFirstName());
            stmt.setString(3, guest.getGuestLastName());
            int rowInserted = stmt.executeUpdate();
            if (rowInserted > 0) {
                System.out.println("A new guest was inserted successfully!");
            }
        } catch (SQLException ex) {
            System.err.println(ex.toString());
        }
    }
    
    /**
     * Update a customer entity in database if it exists using a customer object
     * @param guest
     */
    @Override
    public void update(Guest guest) {
        DB db = DB.getInstance();
        try {
            String sql = "UPDATE HT_Guest SET guestFirstName=?, guestLastName=? WHERE guestID=?";
            PreparedStatement stmt = db.getPreparedStatement(sql);
            stmt.setString(1, guest.getGuestFirstName());
            stmt.setString(2, guest.getGuestLastName());
            stmt.setInt(3, guest.getGuestID());
            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("An existing guest was updated successfully!");
            }
        } catch (SQLException ex) {
            System.err.println(ex.toString());
        }
    }
    
    /**
     * Delete a customer from customer table if the entity exists
     * @param guest 
     */
    @Override
    public void delete(Guest guest) {
        DB db = DB.getInstance();
        try {
            String sql = "DELETE FROM HT_Guest WHERE guestID = ?";
            PreparedStatement stmt = db.getPreparedStatement(sql);
            stmt.setInt(1, guest.getGuestID());
            int rowsDeleted = stmt.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("A guest was deleted successfully!");
            }
        } catch (SQLException ex) {
            System.err.println(ex.toString());
        }
    }
    
    /**
     * Get all column names in a list array
     * @return 
     */
    @Override
    public List<String> getColumnNames() {
        DB db = DB.getInstance();
        ResultSet rs = null;
        List<String> headers = new ArrayList<>();
        try {
            String sql = "SELECT * FROM HT_Guest WHERE guestID = -1";//We just need this sql query to get the column headers
            rs = db.executeQuery(sql);
            ResultSetMetaData rsmd = rs.getMetaData();
            //Get number of columns in the result set
            int numberCols = rsmd.getColumnCount();
            for (int i = 1; i <= numberCols; i++) {
                headers.add(rsmd.getColumnLabel(i));//Add column headers to the list
            }
            return headers;
        } catch (SQLException ex) {
            System.err.println(ex.toString());
            return null;
        } 
    }
}
