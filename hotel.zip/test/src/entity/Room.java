/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;
/**
 *
 * @author Gokhan
 */
public class Room 
{
    private int roomID;
    private int roomSpaceNeeded;
    private boolean roomAvailable;
    
    public Room(int roomID, int roomSpaceNeeded, boolean roomAvailable)
    {
        this.roomID = roomID;
        this.roomSpaceNeeded = roomSpaceNeeded;
        this.roomAvailable = roomAvailable;

    }

    public int getRoomID() {
        return roomID;
    }

    public int getRoomSpaceNeeded() {
        return roomSpaceNeeded;
    }

    public boolean getRoomAvailable() {
        return roomAvailable;
    }

    @Override
    public String toString() {
        return "Room{" + "roomID=" + roomID + ", roomSpaceNeeded=" + roomSpaceNeeded + ", roomAvailable=" + roomAvailable + '}';
    }
}
