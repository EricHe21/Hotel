CREATE TABLE HT_Employee(
    employeeID int NOT NULL PRIMARY KEY,
    employeeFirstName VARCHAR(20) NOT NULL,
    employeeLastName VARCHAR(20) NOT NULL
);