CREATE TABLE HT_Guest(
    guestID int NOT NULL PRIMARY KEY,
    guestFirstName VARCHAR(20) NOT NULL,
    guestLastName VARCHAR(20) NOT NULL
);