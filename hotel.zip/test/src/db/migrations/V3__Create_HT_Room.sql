CREATE TABLE HT_Room(
    roomID int NOT NULL PRIMARY KEY,
    roomSpaceNeeded int NOT NULL,
    roomAvailable Boolean NOT NULL
);