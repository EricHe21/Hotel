CREATE TABLE HT_Reservation(
    reservationID int NOT NULL PRIMARY KEY,
    guestID int NOT NULL,
    employeeID int NOT NULL,
    roomID int NOT NULL,
    checkIn TIMESTAMP not null,
    FOREIGN KEY (guestID) REFERENCES HT_Guest(guestID),
    FOREIGN KEY (employeeID) REFERENCES HT_Employee(employeeID),
    FOREIGN KEY (roomID) REFERENCES HT_Room(roomID)

);